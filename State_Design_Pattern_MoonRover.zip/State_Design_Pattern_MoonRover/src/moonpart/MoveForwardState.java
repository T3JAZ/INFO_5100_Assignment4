/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moonpart;

/**
 *
 * @author Tejas
 */
public class MoveForwardState implements RoverState {
    private final Rover rover;

    public MoveForwardState(Rover rover) {
        this.rover = rover;
    }

    @Override
    public void moveForward() {
        System.out.println("Already moving forward.");
    }

    @Override
    public void moveBackward() {
        rover.setState(new MoveBackwardState(rover));
    }

    @Override
    public void stop() {
        rover.setState(new IdleState(rover));
    }
}
