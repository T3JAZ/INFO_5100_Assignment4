/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moonpart;

/**
 *
 * @author Tejas
 */
public class IdleState implements RoverState {
    private final Rover rover;

    public IdleState(Rover rover) {
        this.rover = rover;
    }

    @Override
    public void moveForward() {
        rover.setState(new MoveForwardState(rover));
    }

    @Override
    public void moveBackward() {
        rover.setState(new MoveBackwardState(rover));
    }

    @Override
    public void stop() {
        System.out.println("Already stopped.");
    }
}
