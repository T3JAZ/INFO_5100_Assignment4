/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moonpart;

/**
 *
 * @author Tejas
 */
public class Rover {
    private RoverState state;

    public Rover() {
        state = new IdleState(this);
    }

    public void setState(RoverState state) {
        this.state = state;
    }

    public void moveForward() {
        state.moveForward();
    }

    public void moveBackward() {
        state.moveBackward();
    }

    public void stop() {
        state.stop();
    }

    public Object getState() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from
                                                                       // nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
