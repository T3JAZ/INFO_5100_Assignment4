/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moonpart;

/**
 *
 * @author Tejas
 */
public class MoveBackwardState implements RoverState {
    private final Rover rover;

    public MoveBackwardState(Rover rover) {
        this.rover = rover;
    }

    @Override
    public void moveForward() {
        rover.setState(new MoveForwardState(rover));
    }

    @Override
    public void moveBackward() {
        System.out.println("Already moving backward.");
    }

    @Override
    public void stop() {
        rover.setState(new IdleState(rover));
    }
}