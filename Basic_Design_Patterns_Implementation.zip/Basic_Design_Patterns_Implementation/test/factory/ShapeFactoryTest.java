/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package factory;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tejas
 */
public class ShapeFactoryTest {
    private final ShapeFactory shapeFactory = new ShapeFactory();

    @Test
    public void testCircle() {
        Shape shape = shapeFactory.getShape("CIRCLE");
        assertTrue(shape instanceof Circle);
    }

    @Test
    public void testRectangle() {
        Shape shape = shapeFactory.getShape("RECTANGLE");
        assertTrue(shape instanceof Rectangle);
    }

    @Test
    public void testSquare() {
        Shape shape = shapeFactory.getShape("SQUARE");
        assertTrue(shape instanceof Square);
    }

    @Test
    public void testInvalidShape() {
        Shape shape = shapeFactory.getShape("TRIANGLE");
        assertNull(shape);
    }
}