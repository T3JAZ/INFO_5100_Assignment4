/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package facade;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tejas
 */
public class ShapeMakerTest {
    private final ShapeMaker shapeMaker = new ShapeMaker();

    @Test
    public void testDrawCircle() {
        String expectedOutput = "Circle::draw()";
        String actualOutput = captureOutput(() -> shapeMaker.drawCircle());
        assertEquals(expectedOutput, actualOutput);
    }

    @Test
    public void testDrawRectangle() {
        String expectedOutput = "Rectangle::draw()";
        String actualOutput = captureOutput(() -> shapeMaker.drawRectangle());
        assertEquals(expectedOutput, actualOutput);
    }

    @Test
    public void testDrawSquare() {
        String expectedOutput = "Square::draw()";
        String actualOutput = captureOutput(() -> shapeMaker.drawSquare());
        assertEquals(expectedOutput, actualOutput);
    }

    private String captureOutput(Runnable runnable) {
        PrintStream originalOut = System.out;
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        runnable.run();
        System.setOut(originalOut);
        return outputStream.toString().trim();
    }
}